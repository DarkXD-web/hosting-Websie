import PromoBanner from "@/components/promo-banner"
import Navbar from "@/components/navbar"
import HeroSection from "@/components/hero-section"
import PricingSection from "@/components/pricing-section"
import FeaturesSection from "@/components/features-section"
import GamesSection from "@/components/games-section"
import ControlPanelSection from "@/components/control-panel-section"
import LocationsSection from "@/components/locations-section"
import TestimonialsSection from "@/components/testimonials-section"
import PartnersSection from "@/components/partners-section"
import CTASection from "@/components/cta-section"
import Footer from "@/components/footer"

export default function Home() {
  return (
    <main className="min-h-screen bg-[#0d0f1a] text-white overflow-x-hidden">
      <PromoBanner />
      <Navbar />
      <HeroSection />
      <PricingSection />
      <FeaturesSection />
      <GamesSection />
      <ControlPanelSection />
      <LocationsSection />
      <TestimonialsSection />
      <PartnersSection />
      <CTASection />
      <Footer />
    </main>
  )
}
