"use client"

import { useState } from "react"
import { Sparkles, HardDrive, Cpu, Database, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import ScrollAnimation from "@/components/scroll-animation"

const plans = [
  {
    name: "Dirt",
    ram: 2,
    price: 5.99,
    storage: 10,
    cpu: "200%",
    backups: 0,
    description: "Good for testing or saving your world files.",
    color: "from-amber-700 to-amber-900",
    image: "https://wisehosting.com/images/heads/zombie.webp",
  },
  {
    name: "Stone",
    ram: 4,
    price: 11.99,
    storage: 25,
    cpu: "350%",
    backups: 1,
    description: "Basic servers & some modpacks.",
    color: "from-slate-500 to-slate-600",
    image: "https://wisehosting.com/images/heads/creeper.webp",
  },
  {
    name: "Iron",
    ram: 6,
    price: 17.99,
    storage: 35,
    cpu: "450%",
    backups: 2,
    popular: true,
    description: "Basic servers & some modpacks.",
    color: "from-zinc-400 to-zinc-500",
    image: "https://wisehosting.com/images/heads/skeleton.webp",
  },
  {
    name: "Gold",
    ram: 8,
    price: 23.99,
    storage: 50,
    cpu: "500%",
    backups: 2,
    description: "Advanced servers & all modpacks.",
    color: "from-yellow-500 to-orange-600",
    image: "https://wisehosting.com/images/heads/blaze.webp",
  },
  {
    name: "Custom",
    ram: null,
    price: null,
    startingPrice: 1.49,
    isCustom: true,
    description: "Fully tailored to your needs.",
    color: "from-purple-600 to-violet-600",
    image: "https://wisehosting.com/images/heads/warden.webp",
  },
]

export default function PricingSection() {
  const [billing, setBilling] = useState<"monthly" | "quarterly" | "annually">("monthly")
  const [hoveredPlan, setHoveredPlan] = useState<number | null>(null)
  const multipliers = { monthly: 1, quarterly: 0.9, annually: 0.8 }

  return (
    <section className="relative py-28" id="pricing">
      <div
        className="absolute inset-0 opacity-10 bg-cover bg-center"
        style={{ backgroundImage: "url('https://wisehosting.com/images/screenshots/cave_8.avif')" }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-[#0d0f1a] via-[#0d0f1a]/95 to-[#0d0f1a]" />

      <div className="max-w-7xl mx-auto px-4 relative">
        {/* Header */}
        <ScrollAnimation className="text-center mb-14">
          <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-sm font-medium bg-cyan-500/10 border border-cyan-500/20 text-cyan-400">
            <Sparkles className="w-4 h-4" />
            Simple, Transparent Pricing
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mt-4 mb-4">
            Everything you need for a Minecraft server.
          </h2>
          <p className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-emerald-400 bg-clip-text text-transparent">
            From $5.99 per month.
          </p>
          <p className="text-slate-400 text-lg mt-3">Set up in under 60 seconds. Cancel anytime.</p>

          <div className="flex justify-center mt-10">
            <div className="bg-[#1a1d2e] rounded-xl p-1.5 border border-slate-700/50 flex gap-1 relative">
              {(["monthly", "quarterly", "annually"] as const).map((type) => (
                <button
                  key={type}
                  onClick={() => setBilling(type)}
                  className={`px-6 py-2.5 rounded-lg text-sm font-medium transition-all duration-300 flex items-center gap-2 relative z-10 ${
                    billing === type ? "text-white" : "text-slate-400 hover:text-white"
                  }`}
                >
                  {billing === type && (
                    <span
                      className="absolute inset-0 bg-gradient-to-r from-cyan-500/20 to-emerald-500/20 border border-cyan-500/30 rounded-lg transition-all duration-300"
                      style={{ animation: "fadeScale 0.3s ease-out" }}
                    />
                  )}
                  <span className="relative z-10">{type.charAt(0).toUpperCase() + type.slice(1)}</span>
                  {type !== "monthly" && (
                    <span className="relative z-10 bg-green-500/20 text-emerald-400 text-[10px] px-1.5 py-0.5 rounded-full">
                      -{type === "quarterly" ? "10" : "20"}%
                    </span>
                  )}
                </button>
              ))}
            </div>
          </div>
        </ScrollAnimation>

        {/* Pricing Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-5 mt-12">
          {plans.map((plan, index) => (
            <ScrollAnimation key={plan.name} delay={index * 100}>
              <div
                onMouseEnter={() => setHoveredPlan(index)}
                onMouseLeave={() => setHoveredPlan(null)}
                className={`relative rounded-2xl p-6 transition-all duration-300 ${
                  plan.popular
                    ? "bg-gradient-to-b from-[#1e2235] to-[#1a1d2e] border-2 border-cyan-500/50 shadow-[0_0_30px_rgba(6,182,212,0.1)] -mt-2"
                    : "bg-[#1a1d2e] border border-slate-700/50 hover:border-slate-700/80"
                }`}
                style={{
                  transform: hoveredPlan === index ? "translateY(-8px) scale(1.02)" : "translateY(0) scale(1)",
                }}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-gradient-to-r from-yellow-500 to-orange-500 text-black text-xs font-bold px-4 py-1.5 rounded-full whitespace-nowrap">
                    RECOMMENDED
                  </div>
                )}

                {/* Plan Header - Subtle tilt animation for mob icons */}
                <div className="flex items-center gap-3 mb-4">
                  <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${plan.color} p-0.5`}>
                    <div className="w-full h-full rounded-[10px] bg-[#1a1d2e] flex items-center justify-center overflow-hidden">
                      <img
                        src={plan.image || "/placeholder.svg"}
                        alt={plan.name}
                        className="w-10 h-10 object-contain transition-all duration-300"
                        style={{
                          transform: hoveredPlan === index ? "scale(1.15) rotate(-5deg)" : "scale(1) rotate(0deg)",
                        }}
                      />
                    </div>
                  </div>
                  <div>
                    <div className="text-xl font-bold bg-gradient-to-r from-cyan-400 to-emerald-400 bg-clip-text text-transparent">
                      {plan.isCustom ? "CUSTOM" : `${plan.ram} GB`}
                    </div>
                    <div className="text-sm text-slate-500 font-medium">{plan.isCustom ? "Build Your Own" : "RAM"}</div>
                  </div>
                </div>

                <p className="text-slate-400 text-sm mb-5 min-h-[40px] leading-relaxed">{plan.description}</p>

                <div className="mb-5">
                  {plan.isCustom ? (
                    <>
                      <div className="text-slate-500 text-sm">Starting at</div>
                      <div>
                        <span className="text-3xl font-bold bg-gradient-to-r from-cyan-400 to-emerald-400 bg-clip-text text-transparent">
                          ${plan.startingPrice}
                        </span>
                        <span className="text-slate-500">/mo</span>
                      </div>
                    </>
                  ) : (
                    <>
                      <div key={billing} className="animate-in fade-in slide-in-from-bottom-1 duration-300">
                        <span className="text-3xl font-bold">${(plan.price! * multipliers[billing]).toFixed(2)}</span>
                        <span className="text-slate-500">/mo</span>
                      </div>
                      {billing !== "monthly" && (
                        <div className="text-sm text-slate-600 line-through animate-in fade-in duration-300">
                          ${plan.price!.toFixed(2)}/mo
                        </div>
                      )}
                    </>
                  )}
                </div>

                {/* Features */}
                {!plan.isCustom && (
                  <div className="flex flex-col gap-3 mb-6">
                    <div className="flex items-center gap-3 text-slate-300">
                      <div className="w-8 h-8 rounded-lg bg-slate-800 flex items-center justify-center">
                        <HardDrive className="w-4 h-4 text-cyan-400" />
                      </div>
                      <span className="text-sm">{plan.storage} GB Storage</span>
                    </div>
                    <div className="flex items-center gap-3 text-slate-300">
                      <div className="w-8 h-8 rounded-lg bg-slate-800 flex items-center justify-center">
                        <Cpu className="w-4 h-4 text-cyan-400" />
                      </div>
                      <span className="text-sm">{plan.cpu} CPU Power</span>
                    </div>
                    <div className="flex items-center gap-3 text-slate-300">
                      <div className="w-8 h-8 rounded-lg bg-slate-800 flex items-center justify-center">
                        <Database className="w-4 h-4 text-cyan-400" />
                      </div>
                      <span className="text-sm">
                        {plan.backups} Backup{plan.backups !== 1 ? "s" : ""}
                      </span>
                    </div>
                  </div>
                )}

                <Button
                  onClick={() => document.getElementById("pricing")?.scrollIntoView({ behavior: "smooth" })}
                  className={`w-full py-5 font-semibold transition-all duration-300 ${
                    plan.popular
                      ? "bg-gradient-to-r from-cyan-500 to-emerald-400 text-black hover:from-cyan-400 hover:to-emerald-300"
                      : plan.isCustom
                        ? "bg-gradient-to-r from-purple-600 to-violet-600 text-white hover:from-purple-500 hover:to-violet-500"
                        : "bg-transparent border border-slate-600 text-slate-300 hover:bg-slate-700/30"
                  }`}
                >
                  {plan.isCustom ? "Start Customizing" : "Order Now"}
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </ScrollAnimation>
          ))}
        </div>

        {/* Footer */}
        <ScrollAnimation delay={500} className="text-center mt-12 text-slate-500 text-sm">
          All plans include: <span className="text-slate-400 mx-1">Unlimited Player Slots</span> •
          <span className="text-slate-400 mx-1">Free Subdomain</span> •
          <span className="text-slate-400 mx-1">DDoS Protection</span> •
          <span className="text-slate-400 mx-1">Full FTP Access</span> •
          <span className="text-slate-400 mx-1">24/7 Support</span>
        </ScrollAnimation>
      </div>

      <style jsx>{`
        @keyframes fadeScale {
          from {
            opacity: 0;
            transform: scale(0.95);
          }
          to {
            opacity: 1;
            transform: scale(1);
          }
        }
      `}</style>
    </section>
  )
}
