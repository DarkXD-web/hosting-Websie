"use client"

import ScrollAnimation from "@/components/scroll-animation"

const partners = [
  {
    name: "Facepunch",
    logo: "https://storyblok.shockbyte.com/f/296405/960x216/bbb91b549b/facepunch-logo.png",
    description: "The creators of Rust, one of the most iconic survival sandbox games ever made.",
  },
  {
    name: "Razer",
    logo: "https://storyblok.shockbyte.com/f/296405/1000x253/fe06755efa/razer.webp",
    description: "A global leader in gaming hardware, known for cutting-edge gear.",
  },
  {
    name: "FiveM",
    logo: "https://storyblok.shockbyte.com/f/296405/1000x338/3a68bde8dd/fivem_gta_v_logo.webp",
    description: "A tooling dev collective enabling enhanced RAGE title experiences.",
  },
]

export default function PartnersSection() {
  return (
    <section className="relative py-20 bg-[#12141f]">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header - Wrapped in ScrollAnimation */}
        <ScrollAnimation className="text-center mb-14">
          <h2 className="text-2xl font-bold">
            OUR TRUSTED <span className="text-cyan-400">PARTNERS</span>
          </h2>
          <p className="text-slate-400 text-lg mt-4">
            We work with top gaming brands to deliver unbeatable hosting experiences.
          </p>
        </ScrollAnimation>

        {/* Partners Grid - Each partner has staggered animation */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {partners.map((partner, i) => (
            <ScrollAnimation key={i} delay={i * 150} direction="scale">
              <div className="text-center group">
                <div className="h-16 flex items-center justify-center mb-4">
                  <img
                    src={partner.logo || "/placeholder.svg"}
                    alt={partner.name}
                    className="max-h-full max-w-[180px] object-contain brightness-0 invert opacity-70 group-hover:opacity-100 transition-all duration-300 group-hover:scale-110"
                  />
                </div>
                <p className="text-slate-400 text-sm">{partner.description}</p>
              </div>
            </ScrollAnimation>
          ))}
        </div>
      </div>
    </section>
  )
}
