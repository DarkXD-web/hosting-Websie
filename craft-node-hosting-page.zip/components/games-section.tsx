"use client"

import { Gamepad2, ArrowRight } from "lucide-react"
import ScrollAnimation from "@/components/scroll-animation"
import Link from "next/link"

const games = [
  {
    name: "Minecraft: Java Edition",
    image: "https://cdn.apexminecrafthosting.com/2.0/games/minecraft/gamecovers/minecraft-boxart.jpg",
    price: "$5.99",
    discount: "-25%",
  },
  {
    name: "Minecraft: Bedrock",
    image: "https://cdn.apexminecrafthosting.com/2.0/games/minecraft_bedrock/gamecovers/minecraft_bedrock-boxart.jpg",
    price: "$2.99",
    discount: "-25%",
  },
  {
    name: "Palworld",
    image: "https://cdn.apexminecrafthosting.com/2.0/games/palworld/gamecovers/palworld-boxart.jpg",
    price: "$16.87",
    discount: "-25%",
  },
  {
    name: "Valheim",
    image: "https://cdn.apexminecrafthosting.com/2.0/games/valheim/gamecovers/valheim-boxart.jpg",
    price: "$5.99",
    discount: "-25%",
  },
  {
    name: "ARK: Survival Evolved",
    image: "https://cdn.apexminecrafthosting.com/2.0/games/ark/gamecovers/ark-boxart.jpg",
    price: "$11.24",
    discount: "-25%",
  },
  {
    name: "Rust",
    image: "https://cdn.apexminecrafthosting.com/2.0/games/rust/gamecovers/rust-boxart.jpg",
    price: "$11.24",
    discount: "-25%",
  },
  {
    name: "Project Zomboid",
    image: "https://cdn.apexminecrafthosting.com/2.0/games/zomboid/gamecovers/zomboid-boxart.jpg",
    price: "$5.99",
    discount: "-25%",
  },
  {
    name: "Terraria",
    image: "https://cdn.apexminecrafthosting.com/2.0/games/terraria/gamecovers/terraria-boxart.jpg",
    price: "$2.99",
    discount: "-25%",
  },
]

export default function GamesSection() {
  return (
    <section className="relative py-24 bg-[#12141f]" id="games">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <ScrollAnimation>
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-10">
            <div>
              <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-sm font-medium bg-pink-500/10 border border-pink-500/20 text-pink-400">
                <Gamepad2 className="w-4 h-4" />
                100+ Games
              </span>
              <h2 className="text-2xl font-bold mt-3">Available Games</h2>
            </div>
            <Link
              href="#games"
              className="text-cyan-400 font-medium text-sm flex items-center gap-2 hover:text-cyan-300 transition-colors group"
            >
              View All Games
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </Link>
          </div>
        </ScrollAnimation>

        {/* Games Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-4">
          {games.map((game, i) => (
            <ScrollAnimation key={i} delay={i * 50}>
              <div className="relative rounded-xl overflow-hidden bg-slate-800 border border-slate-600 cursor-pointer transition-all hover:-translate-y-2 hover:scale-[1.02] hover:border-cyan-500/50 hover:shadow-[0_10px_30px_rgba(6,182,212,0.1)] group">
                <div className="aspect-[3/4] relative overflow-hidden">
                  <img
                    src={game.image || "/placeholder.svg"}
                    alt={game.name}
                    className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  {game.discount && (
                    <span className="absolute top-2 left-2 bg-gradient-to-r from-red-500 to-pink-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">
                      {game.discount}
                    </span>
                  )}
                </div>
                <div className="p-3 bg-[#1a1d2e]">
                  <div className="font-semibold text-xs truncate group-hover:text-cyan-400 transition-colors">
                    {game.name}
                  </div>
                  <div className="text-xs font-bold mt-0.5 bg-gradient-to-r from-cyan-400 to-emerald-400 bg-clip-text text-transparent">
                    from {game.price}
                  </div>
                </div>
              </div>
            </ScrollAnimation>
          ))}
        </div>
      </div>
    </section>
  )
}
