"use client"

import { Server } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function Navbar() {
  return (
    <nav className="sticky top-0 z-50 bg-[#0d0f1a]/95 backdrop-blur-xl border-b border-slate-700/50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link href="#" className="flex items-center gap-2">
            <div className="w-9 h-9 bg-gradient-to-br from-cyan-400 to-emerald-400 rounded-lg flex items-center justify-center">
              <Server className="w-5 h-5 text-[#0d0f1a]" />
            </div>
            <span className="text-xl font-black text-white">CraftNode</span>
          </Link>

          <div className="hidden md:flex items-center gap-1">
            <Link href="#pricing" className="px-4 py-2 text-slate-300 text-sm hover:text-white transition-colors">
              Minecraft Server Hosting
            </Link>
            <Link href="#games" className="px-4 py-2 text-slate-300 text-sm hover:text-white transition-colors">
              Games
            </Link>
            <Link href="#" className="px-4 py-2 text-slate-300 text-sm hover:text-white transition-colors">
              Control Panel
            </Link>
            <Link href="#" className="px-4 py-2 text-slate-300 text-sm hover:text-white transition-colors">
              Support
            </Link>
          </div>

          <div className="hidden md:flex items-center gap-3">
            <Button
              variant="outline"
              size="sm"
              className="border-slate-600 text-slate-300 hover:bg-slate-700/30 bg-transparent transition-transform hover:scale-105"
            >
              Dashboard
            </Button>
            <Link href="#pricing">
              <Button
                size="sm"
                className="bg-gradient-to-r from-lime-500 to-green-500 text-black hover:from-lime-400 hover:to-green-400 transition-transform hover:scale-105"
              >
                Order Now
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </nav>
  )
}
