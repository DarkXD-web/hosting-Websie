"use client"

import { Check, ArrowRight, Play, Shield } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Star } from "lucide-react"
import ScrollAnimation from "@/components/scroll-animation"
import Link from "next/link"

export default function HeroSection() {
  return (
    <section className="relative min-h-[90vh] overflow-hidden py-16 pb-20">
      {/* Background */}
      <div className="absolute inset-0">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `
              linear-gradient(rgba(6, 182, 212, 0.03) 1px, transparent 1px),
              linear-gradient(90deg, rgba(6, 182, 212, 0.03) 1px, transparent 1px)
            `,
            backgroundSize: "50px 50px",
          }}
        />
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-purple-600/20 rounded-full blur-[100px] animate-pulse" />
        <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-cyan-500/20 rounded-full blur-[100px] animate-pulse delay-1000" />
      </div>

      <div className="max-w-7xl mx-auto px-4 relative">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center min-h-[75vh]">
          {/* Left Content */}
          <div className="flex flex-col gap-8">
            {/* Trust Badge */}
            <ScrollAnimation delay={0}>
              <div className="flex items-center gap-3 flex-wrap">
                <div className="flex -space-x-2">
                  <img
                    src="https://randomuser.me/api/portraits/men/32.jpg"
                    alt=""
                    className="w-9 h-9 rounded-full border-2 border-[#0d0f1a] object-cover"
                  />
                  <img
                    src="https://randomuser.me/api/portraits/women/44.jpg"
                    alt=""
                    className="w-9 h-9 rounded-full border-2 border-[#0d0f1a] object-cover"
                  />
                  <img
                    src="https://randomuser.me/api/portraits/men/67.jpg"
                    alt=""
                    className="w-9 h-9 rounded-full border-2 border-[#0d0f1a] object-cover"
                  />
                </div>
                <div className="h-6 w-px bg-slate-600" />
                <span className="text-white font-semibold">Excellent</span>
                <div className="flex gap-0.5">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-green-500 text-green-500" />
                  ))}
                </div>
                <span className="text-slate-400 text-sm">on Trustpilot</span>
              </div>
            </ScrollAnimation>

            {/* Title */}
            <ScrollAnimation delay={100}>
              <h1 className="text-5xl sm:text-6xl lg:text-7xl font-black leading-[1.1] tracking-tight">
                Minecraft
                <br />
                Server{" "}
                <span className="bg-gradient-to-r from-cyan-400 to-emerald-400 bg-clip-text text-transparent">
                  Hosting
                </span>
              </h1>
              <p className="text-lg text-slate-400 max-w-lg mt-4 leading-relaxed">
                Lag-free, customizable servers ready in minutes. Host your adventure today with the most powerful
                hardware!
              </p>
            </ScrollAnimation>

            {/* Features List */}
            <ScrollAnimation delay={200}>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {[
                  "Java & Bedrock Edition Servers",
                  "More than 15,000 Modpacks",
                  "1-Click Mods/Plugins Install",
                  "24/7 Technical Support",
                ].map((feature, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <div className="w-5 h-5 rounded-full bg-green-500/20 flex items-center justify-center">
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                    </div>
                    <span className="text-sm text-slate-300">{feature}</span>
                  </div>
                ))}
              </div>
            </ScrollAnimation>

            {/* CTA Buttons - Buttons now link to pricing section */}
            <ScrollAnimation delay={300}>
              <div className="flex flex-col sm:flex-row gap-4 pt-2">
                <Link href="#pricing">
                  <Button className="bg-gradient-to-r from-lime-500 to-green-500 text-black hover:from-lime-400 hover:to-green-400 px-8 py-6 text-base font-semibold transition-transform hover:scale-105">
                    Rent your server
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>
                </Link>
                <Link href="#games">
                  <Button
                    variant="outline"
                    className="border-slate-600 text-slate-300 hover:bg-slate-700/30 px-8 py-6 text-base bg-transparent transition-transform hover:scale-105"
                  >
                    <Play className="w-4 h-4 mr-2 fill-current" />
                    Discover All Games
                  </Button>
                </Link>
              </div>
            </ScrollAnimation>

            {/* Stats */}
            <ScrollAnimation delay={400}>
              <div className="flex gap-8 pt-4">
                <div>
                  <div className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-emerald-400 bg-clip-text text-transparent">
                    50K+
                  </div>
                  <div className="text-xs text-slate-500 mt-0.5">Active Servers</div>
                </div>
                <div>
                  <div className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-emerald-400 bg-clip-text text-transparent">
                    99.9%
                  </div>
                  <div className="text-xs text-slate-500 mt-0.5">Uptime</div>
                </div>
                <div>
                  <div className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-emerald-400 bg-clip-text text-transparent">
                    {"<15min"}
                  </div>
                  <div className="text-xs text-slate-500 mt-0.5">Avg Support</div>
                </div>
              </div>
            </ScrollAnimation>
          </div>

          {/* Right Content - Hero Image */}
          <div className="hidden lg:flex justify-center relative">
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] bg-gradient-to-r from-cyan-500/20 to-emerald-500/20 rounded-full blur-[80px]" />
            <img
              src="https://apexminecrafthosting.com/_astro/hero.DUqUHHgf.png"
              alt="Minecraft Characters"
              className="relative max-w-[500px] animate-float"
            />

            {/* Floating Badge 1 */}
            <div className="absolute top-10 right-0 bg-[#1a1d2e]/90 backdrop-blur-xl border border-slate-600 rounded-xl p-3 flex items-center gap-2 animate-float-delayed">
              <div className="w-8 h-8 rounded-lg bg-green-500/20 flex items-center justify-center">
                <Check className="w-4 h-4 text-emerald-400" />
              </div>
              <div>
                <div className="text-xs font-semibold text-white">Instant Setup</div>
                <div className="text-[10px] text-slate-400">Ready in 60 seconds</div>
              </div>
            </div>

            {/* Floating Badge 2 */}
            <div className="absolute bottom-20 left-0 bg-[#1a1d2e]/90 backdrop-blur-xl border border-slate-600 rounded-xl p-3 flex items-center gap-2 animate-float-delayed-2">
              <div className="w-8 h-8 rounded-lg bg-cyan-500/20 flex items-center justify-center">
                <Shield className="w-4 h-4 text-cyan-400" />
              </div>
              <div>
                <div className="text-xs font-semibold text-white">DDoS Protected</div>
                <div className="text-[10px] text-slate-400">Enterprise security</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes float {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-10px); }
        }
        @keyframes float-delayed {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-8px); }
        }
        @keyframes float-delayed-2 {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-12px); }
        }
        .animate-float {
          animation: float 4s ease-in-out infinite;
        }
        .animate-float-delayed {
          animation: float-delayed 3s ease-in-out infinite;
          animation-delay: 0.5s;
        }
        .animate-float-delayed-2 {
          animation: float-delayed-2 3.5s ease-in-out infinite;
          animation-delay: 1s;
        }
      `}</style>
    </section>
  )
}
