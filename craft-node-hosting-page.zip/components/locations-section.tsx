"use client"

import { useState } from "react"
import { Signal, Clock, MapPin, ChevronRight } from "lucide-react"
import ScrollAnimation from "@/components/scroll-animation"
import dynamic from "next/dynamic"

const Globe3D = dynamic(() => import("@/components/globe-3d"), {
  ssr: false,
  loading: () => (
    <div className="w-full h-[450px] flex items-center justify-center">
      <div className="w-48 h-48 rounded-full border-2 border-cyan-500/30 border-t-cyan-500 animate-spin" />
    </div>
  ),
})

const locations = [
  { name: "Los Angeles", country: "USA", flag: "🇺🇸", ping: "12ms" },
  { name: "Miami", country: "USA", flag: "🇺🇸", ping: "18ms" },
  { name: "New York", country: "USA", flag: "🇺🇸", ping: "15ms" },
  { name: "Dallas", country: "USA", flag: "🇺🇸", ping: "14ms" },
  { name: "Seattle", country: "USA", flag: "🇺🇸", ping: "16ms" },
  { name: "Toronto", country: "Canada", flag: "🇨🇦", ping: "20ms" },
  { name: "London", country: "UK", flag: "🇬🇧", ping: "25ms" },
  { name: "Paris", country: "France", flag: "🇫🇷", ping: "28ms" },
  { name: "Frankfurt", country: "Germany", flag: "🇩🇪", ping: "26ms" },
  { name: "Amsterdam", country: "Netherlands", flag: "🇳🇱", ping: "24ms" },
  { name: "Singapore", country: "Singapore", flag: "🇸🇬", ping: "45ms" },
  { name: "Tokyo", country: "Japan", flag: "🇯🇵", ping: "50ms" },
  { name: "Sydney", country: "Australia", flag: "🇦🇺", ping: "55ms" },
  { name: "São Paulo", country: "Brazil", flag: "🇧🇷", ping: "35ms" },
]

export default function LocationsSection() {
  const [activeLocation, setActiveLocation] = useState<number | null>(null)

  const handleGlobeLocationClick = (index: number) => {
    setActiveLocation(activeLocation === index ? null : index)
  }

  return (
    <section className="relative py-24 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-[#12141f] to-[#0d0f1a]" />

      <div className="max-w-7xl mx-auto px-4 relative">
        {/* Header */}
        <ScrollAnimation className="text-center mb-14">
          <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-sm font-medium bg-cyan-500/10 border border-cyan-500/20 text-cyan-400">
            🌍 Global Infrastructure
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mt-4">
            Worldwide Server{" "}
            <span className="bg-gradient-to-r from-cyan-400 to-emerald-400 bg-clip-text text-transparent">
              Locations
            </span>
          </h2>
          <p className="text-slate-400 text-lg mt-4">
            Choose from 14+ data centers across the globe. Click on dots or drag to rotate.
          </p>
        </ScrollAnimation>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
          {/* 3D Globe */}
          <ScrollAnimation direction="left">
            <Globe3D selectedLocation={activeLocation} onLocationClick={handleGlobeLocationClick} />
            <div className="text-center text-slate-500 text-sm mt-2">
              Click markers to select • Drag to rotate • Green = selected
            </div>
          </ScrollAnimation>

          {/* Locations List */}
          <ScrollAnimation direction="right">
            <div className="grid grid-cols-2 gap-3 max-h-[480px] overflow-y-auto pr-2 custom-scrollbar">
              {locations.map((location, index) => (
                <div
                  key={index}
                  onClick={() => setActiveLocation(activeLocation === index ? null : index)}
                  className={`relative p-4 rounded-xl cursor-pointer transition-all duration-300 hover:scale-[1.02] ${
                    activeLocation === index
                      ? "bg-gradient-to-r from-emerald-500/20 to-cyan-500/20 border border-emerald-500/50"
                      : "bg-[#1a1d2e] border border-slate-700/50 hover:border-cyan-500/30 hover:bg-[#1e2235]"
                  }`}
                >
                  {activeLocation === index && (
                    <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-8 bg-gradient-to-b from-emerald-400 to-cyan-400 rounded-r-full" />
                  )}
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{location.flag}</span>
                    <div className="flex-1 min-w-0">
                      <div className="font-semibold text-sm truncate">{location.name}</div>
                      <div className="text-xs text-slate-500">{location.country}</div>
                    </div>
                    <span
                      className={`text-xs font-medium px-2 py-1 rounded-full transition-colors duration-300 ${
                        activeLocation === index
                          ? "bg-emerald-500/20 text-emerald-400"
                          : "bg-slate-700/50 text-slate-400"
                      }`}
                    >
                      {location.ping}
                    </span>
                  </div>
                </div>
              ))}
            </div>

            {/* Location Details */}
            {activeLocation !== null && (
              <div className="mt-4 p-5 rounded-xl bg-gradient-to-r from-emerald-500/10 to-cyan-500/10 border border-emerald-500/20 animate-in fade-in slide-in-from-bottom-2 duration-300">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <span className="text-3xl">{locations[activeLocation].flag}</span>
                    <div>
                      <div className="text-xl font-bold">{locations[activeLocation].name}</div>
                      <div className="text-slate-400 text-sm">{locations[activeLocation].country}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-emerald-400">
                    <Signal className="w-4 h-4" />
                    <span className="font-semibold">{locations[activeLocation].ping}</span>
                  </div>
                </div>
                <div className="flex gap-4 text-sm text-slate-400">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4" />
                    <span>99.9% Uptime</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    <span>Tier 4 Data Center</span>
                  </div>
                </div>
                <button className="mt-4 text-emerald-400 font-medium text-sm flex items-center gap-2 hover:translate-x-1 transition-transform">
                  Select this location
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </ScrollAnimation>
        </div>
      </div>
    </section>
  )
}
