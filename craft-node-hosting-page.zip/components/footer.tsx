"use client"

import { Server } from "lucide-react"
import Link from "next/link"
import ScrollAnimation from "@/components/scroll-animation"

export default function Footer() {
  return (
    <footer className="bg-[#0a0c14] border-t border-slate-800 py-16">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-8 mb-12">
          {/* Brand - Wrapped in ScrollAnimation */}
          <ScrollAnimation className="col-span-2 lg:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-9 h-9 bg-gradient-to-br from-cyan-400 to-emerald-400 rounded-lg flex items-center justify-center">
                <Server className="w-5 h-5 text-[#0d0f1a]" />
              </div>
              <span className="text-xl font-black text-white">CraftNode</span>
            </div>
            <p className="text-slate-400 text-sm mb-6 max-w-[20rem]">
              Premium game server hosting with instant setup, powerful hardware, and 24/7 support. Trusted by 50,000+
              gamers worldwide.
            </p>
            <div className="flex gap-3">
              {["T", "D", "Y"].map((letter, i) => (
                <a
                  key={i}
                  href="#"
                  className="w-9 h-9 rounded-lg bg-slate-800 flex items-center justify-center text-slate-400 text-sm hover:bg-slate-700 hover:text-white transition-all hover:scale-110"
                >
                  {letter}
                </a>
              ))}
            </div>
          </ScrollAnimation>

          {/* Links - Each section has staggered animation */}
          {[
            {
              title: "Games",
              links: [
                { name: "Minecraft Java", href: "#games" },
                { name: "Minecraft Bedrock", href: "#games" },
                { name: "Rust", href: "#games" },
                { name: "ARK", href: "#games" },
                { name: "Valheim", href: "#games" },
                { name: "Palworld", href: "#games" },
                { name: "All Games", href: "#games" },
              ],
            },
            {
              title: "Support",
              links: [
                { name: "Help Center", href: "#" },
                { name: "Contact Us", href: "#" },
                { name: "Server Status", href: "#" },
                { name: "Knowledgebase", href: "#" },
              ],
            },
            {
              title: "Company",
              links: [
                { name: "About Us", href: "#" },
                { name: "Careers", href: "#" },
                { name: "Blog", href: "#" },
                { name: "Partners", href: "#" },
              ],
            },
            {
              title: "Legal",
              links: [
                { name: "Terms of Service", href: "#" },
                { name: "Privacy Policy", href: "#" },
                { name: "Acceptable Use", href: "#" },
                { name: "SLA", href: "#" },
              ],
            },
          ].map((section, i) => (
            <ScrollAnimation key={i} delay={i * 100}>
              <h4 className="font-semibold mb-4">{section.title}</h4>
              <ul className="flex flex-col gap-2">
                {section.links.map((link, j) => (
                  <li key={j}>
                    <Link href={link.href} className="text-slate-400 text-sm hover:text-cyan-400 transition-colors">
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </ScrollAnimation>
          ))}
        </div>

        <ScrollAnimation delay={400}>
          <div className="pt-8 border-t border-slate-800 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-slate-500">
            <p>© 2026 CraftNode. All rights reserved.</p>
            <div className="flex gap-6">
              {["Terms", "Privacy", "Cookies"].map((link, i) => (
                <Link key={i} href="#" className="hover:text-slate-400 transition-colors">
                  {link}
                </Link>
              ))}
            </div>
          </div>
        </ScrollAnimation>
      </div>
    </footer>
  )
}
