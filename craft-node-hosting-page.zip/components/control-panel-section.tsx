"use client"

import { useState } from "react"
import { Check } from "lucide-react"
import ScrollAnimation from "@/components/scroll-animation"

const panelFeatures = [
  {
    id: "console",
    title: "Real-Time Console",
    description: "The console now feels smooth and instant, with a beautiful new design and brand new features.",
    image: "https://storyblok.shockbyte.com/f/296405/1392x1000/cff43386a4/console.webp/m/1440x0",
  },
  {
    id: "modpack",
    title: "Modpack Installer",
    description: "Manage and find the exact modpacks you need with advanced filtering.",
    image: "https://storyblok.shockbyte.com/f/296405/1392x1000/debc23ec0a/modpacks.webp/m/1440x0",
  },
  {
    id: "instances",
    title: "Server Instances",
    description: "Create different server configuration setups and swap between them on the fly.",
    image: "https://storyblok.shockbyte.com/f/296405/1392x1000/92b99b5837/instances.webp/m/1440x0",
  },
  {
    id: "config",
    title: "Config Manager",
    description: "Edit all configs with ease from the comfort of your panel.",
    image: "https://storyblok.shockbyte.com/f/296405/1392x1000/a204055180/config.webp/m/1440x0",
  },
  {
    id: "backups",
    title: "Backups",
    description: "Making or restoring a backup is as simple as one click.",
    image: "https://storyblok.shockbyte.com/f/296405/1392x1000/bcf9b360d6/backup.webp/m/1440x0",
  },
]

export default function ControlPanelSection() {
  const [activePanel, setActivePanel] = useState("console")
  const [isTransitioning, setIsTransitioning] = useState(false)
  const activeFeature = panelFeatures.find((f) => f.id === activePanel)

  const handlePanelChange = (id: string) => {
    if (id !== activePanel) {
      setIsTransitioning(true)
      setTimeout(() => {
        setActivePanel(id)
        setTimeout(() => setIsTransitioning(false), 50)
      }, 150)
    }
  }

  return (
    <section className="relative py-24">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <ScrollAnimation className="text-center mb-14">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold">
            EXPERIENCE THE NEW <span className="text-cyan-400">CONTROL PANEL</span>
          </h2>
          <p className="text-slate-400 text-lg mt-4">
            Our new panel has all the features you need and more! Get a new server today and discover them all.
          </p>
        </ScrollAnimation>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Features List */}
          <ScrollAnimation direction="left">
            <div className="flex flex-col gap-3">
              {panelFeatures.map((feature, index) => (
                <div
                  key={feature.id}
                  onClick={() => handlePanelChange(feature.id)}
                  className={`p-4 rounded-xl cursor-pointer transition-all duration-300 ${
                    activePanel === feature.id
                      ? "bg-cyan-500/10 border border-cyan-500/30"
                      : "bg-[#1a1d2e] border border-transparent hover:border-slate-600"
                  }`}
                  style={{
                    animationDelay: `${index * 100}ms`,
                  }}
                >
                  <div className="flex items-start gap-3">
                    <div
                      className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5 transition-all duration-300 ${
                        activePanel === feature.id ? "bg-cyan-500 scale-110" : "bg-slate-600"
                      }`}
                    >
                      <Check className={`w-4 h-4 ${activePanel === feature.id ? "text-white" : "text-slate-400"}`} />
                    </div>
                    <div>
                      <div
                        className={`font-semibold mb-1 transition-colors duration-300 ${activePanel === feature.id ? "text-cyan-400" : ""}`}
                      >
                        {feature.title}
                      </div>
                      <div
                        className={`overflow-hidden transition-all duration-300 ${
                          activePanel === feature.id ? "max-h-20 opacity-100" : "max-h-0 opacity-0"
                        }`}
                      >
                        <p className="text-slate-400 text-sm">{feature.description}</p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </ScrollAnimation>

          <ScrollAnimation direction="right">
            <div className="relative">
              <div className="rounded-xl overflow-hidden border border-slate-600 shadow-2xl relative">
                {/* All images stacked, only active one visible */}
                {panelFeatures.map((feature) => (
                  <img
                    key={feature.id}
                    src={feature.image || "/placeholder.svg"}
                    alt={feature.title}
                    className={`w-full h-auto transition-all duration-500 ${
                      activePanel === feature.id ? "opacity-100 relative" : "opacity-0 absolute inset-0"
                    } ${isTransitioning ? "scale-[1.02] blur-[1px]" : "scale-100 blur-0"}`}
                  />
                ))}
              </div>
              {/* Glow effect */}
              <div className="absolute -inset-4 bg-gradient-to-r from-cyan-500/10 to-emerald-500/10 rounded-2xl blur-2xl -z-10 opacity-50" />
            </div>
          </ScrollAnimation>
        </div>
      </div>
    </section>
  )
}
