"use client"

import { Sparkles, Zap, Shield, Headphones, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import ScrollAnimation from "@/components/scroll-animation"

export default function CTASection() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  const scrollToPricing = () => {
    document.getElementById("pricing")?.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <section className="relative py-32 overflow-hidden">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-to-r from-cyan-500/10 via-purple-600/10 to-emerald-500/10 rounded-full blur-[150px]" />
      <div
        className="absolute inset-0"
        style={{
          backgroundImage: `
            linear-gradient(rgba(6, 182, 212, 0.03) 1px, transparent 1px),
            linear-gradient(90deg, rgba(6, 182, 212, 0.03) 1px, transparent 1px)
          `,
          backgroundSize: "40px 40px",
        }}
      />

      <div className="max-w-7xl mx-auto px-4 relative">
        <div className="max-w-4xl mx-auto text-center">
          <ScrollAnimation>
            <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-sm font-medium bg-gradient-to-r from-cyan-500/10 to-emerald-500/10 border border-cyan-500/20">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <span className="text-cyan-400 font-medium">Start Playing Today</span>
            </span>
          </ScrollAnimation>

          <ScrollAnimation delay={100}>
            <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold mt-6 mb-6 leading-tight">
              Ready to Start Your
              <br />
              <span className="bg-gradient-to-r from-cyan-400 to-emerald-400 bg-clip-text text-transparent">
                Minecraft Adventure?
              </span>
            </h2>
          </ScrollAnimation>

          <ScrollAnimation delay={200}>
            <p className="text-xl text-slate-400 max-w-2xl mx-auto mb-10">
              Join thousands of gamers who trust us with their servers. Start playing in under 60 seconds.
            </p>
          </ScrollAnimation>

          {/* Pills */}
          <ScrollAnimation delay={300}>
            <div className="flex flex-wrap justify-center gap-4 mb-10">
              {[
                { icon: Zap, text: "Instant Setup" },
                { icon: Shield, text: "DDoS Protected" },
                { icon: Headphones, text: "24/7 Support" },
              ].map((pill, i) => (
                <div
                  key={i}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-full bg-slate-800/50 border border-slate-600 backdrop-blur-sm hover:scale-105 hover:-translate-y-0.5 transition-all cursor-default"
                >
                  <pill.icon className="w-4 h-4 text-cyan-400" />
                  <span className="text-sm text-slate-300 font-medium">{pill.text}</span>
                </div>
              ))}
            </div>
          </ScrollAnimation>

          <ScrollAnimation delay={400}>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                onClick={scrollToTop}
                className="bg-gradient-to-r from-lime-500 to-green-500 text-black hover:from-lime-400 hover:to-green-400 px-10 py-6 text-lg font-semibold transition-transform hover:scale-105"
              >
                Get Started Now
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
              <Button
                onClick={scrollToPricing}
                variant="outline"
                className="border-slate-600 text-slate-300 hover:bg-slate-700/30 px-10 py-6 text-lg bg-transparent transition-transform hover:scale-105"
              >
                View All Plans
              </Button>
            </div>
          </ScrollAnimation>

          <ScrollAnimation delay={500}>
            <p className="mt-10 text-slate-500 text-sm">
              <span className="text-emerald-400">✓</span> 72-hour money back guarantee
              <span className="mx-2">•</span>
              <span className="text-emerald-400">✓</span> No hidden fees
              <span className="mx-2">•</span>
              <span className="text-emerald-400">✓</span> Cancel anytime
            </p>
          </ScrollAnimation>
        </div>
      </div>
    </section>
  )
}
