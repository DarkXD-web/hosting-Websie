"use client"

import { Globe, Users, Headphones, Database, History, Gamepad2, Zap, Shield, HardDrive } from "lucide-react"
import ScrollAnimation from "@/components/scroll-animation"

const features = [
  {
    icon: Globe,
    title: "Free Subdomain",
    description: "All orders include a free web address for your server making it easy to connect for all.",
    color: "from-blue-500 to-cyan-500",
  },
  {
    icon: Users,
    title: "Unlimited Slots",
    description: "All our servers come with unlimited slots, so your community can grow without boundaries.",
    color: "from-purple-600 to-pink-500",
  },
  {
    icon: Headphones,
    title: "24/7 Server Support",
    description: "Expert support team available around the clock via live chat from experienced administrators.",
    color: "from-emerald-500 to-green-500",
  },
  {
    icon: Database,
    title: "Automated Backups",
    description:
      "Offsite automatic backups guarantee your data will not be lost due to any configurations or failures.",
    color: "from-orange-500 to-amber-400",
  },
  {
    icon: History,
    title: "One-Click Installer",
    description: "Instantly switch between 20+ games, and over 2000+ mod packs at the click of a button.",
    color: "from-cyan-500 to-blue-500",
  },
  {
    icon: Gamepad2,
    title: "Game Switching",
    description: "Swap your server to any of our 100+ covered games anytime, at no extra charge!",
    color: "from-pink-500 to-rose-500",
  },
]

export default function FeaturesSection() {
  return (
    <section className="relative py-28 overflow-hidden">
      <div className="absolute top-1/4 left-0 w-96 h-96 bg-cyan-500/5 rounded-full blur-[150px]" />
      <div className="absolute bottom-1/4 right-0 w-96 h-96 bg-purple-600/5 rounded-full blur-[150px]" />

      <div className="max-w-7xl mx-auto px-4 relative">
        {/* Header */}
        <ScrollAnimation className="text-center mb-14">
          <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-sm font-medium bg-purple-600/10 border border-purple-600/20 text-purple-400">
            <Zap className="w-4 h-4" />
            Powerful Features
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mt-4">
            Only At{" "}
            <span className="bg-gradient-to-r from-cyan-400 to-purple-500 bg-clip-text text-transparent">
              CraftNode Hosting
            </span>
          </h2>
          <p className="text-slate-400 text-lg mt-4 max-w-3xl mx-auto">
            We combine cutting edge hardware with industry-leading service to deliver unmatched performance,
            reliability, and ease of use.
          </p>
        </ScrollAnimation>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, i) => (
            <ScrollAnimation key={i} delay={i * 100}>
              <div className="p-6 rounded-2xl bg-[#1a1d2e]/80 border border-slate-700/50 hover:border-slate-700/80 transition-all hover:-translate-y-1 hover:shadow-[0_10px_30px_rgba(6,182,212,0.05)] group h-full">
                <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${feature.color} p-0.5 mb-5`}>
                  <div className="w-full h-full rounded-[10px] bg-[#1a1d2e] flex items-center justify-center">
                    <feature.icon className="w-6 h-6 text-white" />
                  </div>
                </div>
                <h3 className="text-lg font-bold mb-2 group-hover:text-cyan-400 transition-colors">{feature.title}</h3>
                <p className="text-slate-400 text-sm leading-relaxed">{feature.description}</p>
              </div>
            </ScrollAnimation>
          ))}
        </div>

        {/* Highlight Bar */}
        <ScrollAnimation delay={600} className="mt-16">
          <div className="p-6 rounded-2xl bg-gradient-to-r from-cyan-500/10 via-purple-600/10 to-cyan-500/10 border border-slate-700/50">
            <div className="flex flex-wrap justify-center items-center gap-8">
              <div className="flex items-center gap-2 text-slate-300">
                <Zap className="w-5 h-5 text-cyan-400" />
                <span className="font-medium">AMD Ryzen 9 CPUs</span>
              </div>
              <div className="flex items-center gap-2 text-slate-300">
                <Shield className="w-5 h-5 text-cyan-400" />
                <span className="font-medium">DDoS Protection</span>
              </div>
              <div className="flex items-center gap-2 text-slate-300">
                <HardDrive className="w-5 h-5 text-cyan-400" />
                <span className="font-medium">NVMe Storage</span>
              </div>
            </div>
          </div>
        </ScrollAnimation>
      </div>
    </section>
  )
}
