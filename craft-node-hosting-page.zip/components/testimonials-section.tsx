"use client"

import { Star, Quote } from "lucide-react"
import ScrollAnimation from "@/components/scroll-animation"
import AnimatedStars from "@/components/animated-stars"

const testimonials = [
  {
    name: "K N Necroxin",
    date: "03 Dec 2024",
    title: "Best hosting service I've used",
    content:
      "The ease of access to all of your files, video tutorials, 24/7 support, and fair pricing keeps me coming back.",
    avatar: "KN",
  },
  {
    name: "Mike Thompson",
    date: "28 Nov 2024",
    title: "Incredible support team",
    content: "Had an issue with my server and support solved it in minutes. Really happy with the service.",
    avatar: "MT",
  },
  {
    name: "Sarah Chen",
    date: "15 Nov 2024",
    title: "Night and day difference",
    content:
      "We switched from another host and wow. Zero lag, amazing control panel, and the support actually responds!",
    avatar: "SC",
  },
  {
    name: "Alex Rodriguez",
    date: "10 Nov 2024",
    title: "Perfect for modpacks",
    content: "I run multiple modded servers and the performance is incredible. The one-click installer saves hours.",
    avatar: "AR",
  },
]

export default function TestimonialsSection() {
  return (
    <section className="relative py-28 bg-[#12141f]">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <ScrollAnimation className="text-center mb-14">
          <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-sm font-medium bg-green-500/10 border border-green-500/20 text-emerald-400">
            <Star className="w-4 h-4 fill-current" />
            Customer Reviews
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mt-4">
            We're Rated <span className="text-emerald-400">Excellent!</span>
          </h2>

          {/* Rating Display - Stars now animate when scrolling into view */}
          <div className="flex items-center justify-center gap-4 mt-6">
            <AnimatedStars count={5} />
            <div className="text-slate-400">
              <span className="text-white font-bold text-xl">4.8</span> out of 5 based on{" "}
              <span className="text-white font-bold">10,000+</span> reviews
            </div>
          </div>
        </ScrollAnimation>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {testimonials.map((testimonial, i) => (
            <ScrollAnimation key={i} delay={i * 100}>
              <div className="bg-[#1a1d2e]/80 border border-slate-700/50 rounded-2xl p-6 transition-all hover:border-slate-700/80 hover:-translate-y-1 group h-full">
                <Quote className="w-8 h-8 text-cyan-500/20 mb-4" />
                <div className="flex gap-1 mb-4">
                  {[...Array(5)].map((_, j) => (
                    <Star key={j} className="w-4 h-4 fill-green-500 text-green-500" />
                  ))}
                </div>
                <h3 className="font-semibold mb-2 group-hover:text-cyan-400 transition-colors">{testimonial.title}</h3>
                <p className="text-slate-400 text-sm leading-relaxed mb-6 line-clamp-3">{testimonial.content}</p>
                <div className="flex items-center gap-3 pt-4 border-t border-slate-700/50">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-cyan-500 to-emerald-400 flex items-center justify-center font-bold text-sm text-black">
                    {testimonial.avatar}
                  </div>
                  <div>
                    <div className="font-medium text-sm">{testimonial.name}</div>
                    <div className="text-xs text-slate-500">{testimonial.date}</div>
                  </div>
                </div>
              </div>
            </ScrollAnimation>
          ))}
        </div>
      </div>
    </section>
  )
}
