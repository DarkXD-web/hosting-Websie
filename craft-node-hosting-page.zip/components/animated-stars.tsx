"use client"

import { useEffect, useRef, useState } from "react"
import { Star } from "lucide-react"

interface AnimatedStarsProps {
  count?: number
  rating?: number
}

export default function AnimatedStars({ count = 5, rating = 5 }: AnimatedStarsProps) {
  const ref = useRef<HTMLDivElement>(null)
  const [isVisible, setIsVisible] = useState(false)
  const [visibleStars, setVisibleStars] = useState(0)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !isVisible) {
          setIsVisible(true)
        }
      },
      { threshold: 0.5 },
    )

    if (ref.current) {
      observer.observe(ref.current)
    }

    return () => observer.disconnect()
  }, [isVisible])

  useEffect(() => {
    if (isVisible && visibleStars < count) {
      const timer = setTimeout(() => {
        setVisibleStars((prev) => prev + 1)
      }, 150)
      return () => clearTimeout(timer)
    }
  }, [isVisible, visibleStars, count])

  return (
    <div ref={ref} className="flex gap-0.5">
      {[...Array(count)].map((_, i) => (
        <Star
          key={i}
          className={`w-7 h-7 transition-all duration-300 ${
            i < visibleStars
              ? "fill-green-500 text-green-500 scale-100 opacity-100"
              : "fill-transparent text-slate-600 scale-75 opacity-30"
          }`}
          style={{
            transitionDelay: `${i * 50}ms`,
            transform: i < visibleStars ? "scale(1) rotate(0deg)" : "scale(0.5) rotate(-180deg)",
          }}
        />
      ))}
    </div>
  )
}
