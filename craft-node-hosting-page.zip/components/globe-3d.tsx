"use client"

import type React from "react"
import { useRef, useEffect, useState, useCallback } from "react"

const locations = [
  { name: "Los Angeles", lat: 34.05, lng: -118.25 },
  { name: "Miami", lat: 25.76, lng: -80.19 },
  { name: "New York", lat: 40.71, lng: -74.01 },
  { name: "Dallas", lat: 32.78, lng: -96.8 },
  { name: "Seattle", lat: 47.61, lng: -122.33 },
  { name: "Toronto", lat: 43.65, lng: -79.38 },
  { name: "London", lat: 51.51, lng: -0.13 },
  { name: "Paris", lat: 48.86, lng: 2.35 },
  { name: "Frankfurt", lat: 50.11, lng: 8.68 },
  { name: "Amsterdam", lat: 52.37, lng: 4.9 },
  { name: "Singapore", lat: 1.35, lng: 103.82 },
  { name: "Tokyo", lat: 35.68, lng: 139.69 },
  { name: "Sydney", lat: -33.87, lng: 151.21 },
  { name: "São Paulo", lat: -23.55, lng: -46.63 },
]

interface Globe3DProps {
  selectedLocation?: number | null
  onLocationClick?: (index: number) => void
}

export default function Globe3D({ selectedLocation, onLocationClick }: Globe3DProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [rotation, setRotation] = useState(0)
  const [isDragging, setIsDragging] = useState(false)
  const [lastX, setLastX] = useState(0)
  const [hoveredLocation, setHoveredLocation] = useState<number | null>(null)
  const animationRef = useRef<number>()
  const rotationRef = useRef(0)

  // Convert lat/lng to screen coordinates
  const latLngToXY = useCallback((lat: number, lng: number, rot: number, size: number) => {
    const phi = (90 - lat) * (Math.PI / 180)
    const theta = (lng + 180 + rot) * (Math.PI / 180)

    const x = Math.sin(phi) * Math.cos(theta)
    const y = Math.cos(phi)
    const z = Math.sin(phi) * Math.sin(theta)

    const isVisible = z > -0.15
    const scale = (z + 1.5) / 2.5
    const radius = size * 0.38
    const screenX = x * radius + size / 2
    const screenY = -y * radius + size / 2

    return { x: screenX, y: screenY, z, isVisible, scale }
  }, [])

  // Check if a point is near a location marker
  const getLocationAtPoint = useCallback(
    (mouseX: number, mouseY: number, canvasSize: number, currentRotation: number) => {
      for (let i = 0; i < locations.length; i++) {
        const loc = locations[i]
        const pos = latLngToXY(loc.lat, loc.lng, currentRotation, canvasSize)
        if (pos.isVisible) {
          const markerSize = 10 * pos.scale
          const distance = Math.sqrt(Math.pow(mouseX - pos.x, 2) + Math.pow(mouseY - pos.y, 2))
          if (distance < markerSize + 8) {
            return i
          }
        }
      }
      return null
    },
    [latLngToXY],
  )

  useEffect(() => {
    rotationRef.current = rotation
  }, [rotation])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const size = canvas.width
    const centerX = size / 2
    const centerY = size / 2
    const radius = size * 0.38

    const draw = (currentRotation: number) => {
      ctx.clearRect(0, 0, size, size)

      // Outer glow rings
      for (let i = 3; i >= 0; i--) {
        const ringRadius = radius + 15 + i * 12
        ctx.strokeStyle = `rgba(6, 182, 212, ${0.03 + i * 0.02})`
        ctx.lineWidth = 1
        ctx.beginPath()
        ctx.arc(centerX, centerY, ringRadius, 0, Math.PI * 2)
        ctx.stroke()
      }

      // Animated pulse ring
      const pulsePhase = (Date.now() / 1000) % 2
      const pulseRadius = radius + 20 + pulsePhase * 40
      const pulseOpacity = 0.3 * (1 - pulsePhase / 2)
      ctx.strokeStyle = `rgba(6, 182, 212, ${pulseOpacity})`
      ctx.lineWidth = 2
      ctx.beginPath()
      ctx.arc(centerX, centerY, pulseRadius, 0, Math.PI * 2)
      ctx.stroke()

      // Globe gradient background
      const globeGradient = ctx.createRadialGradient(
        centerX - radius * 0.3,
        centerY - radius * 0.3,
        0,
        centerX,
        centerY,
        radius,
      )
      globeGradient.addColorStop(0, "#1e3a5f")
      globeGradient.addColorStop(0.3, "#0f2847")
      globeGradient.addColorStop(0.7, "#0a1a2e")
      globeGradient.addColorStop(1, "#050d15")
      ctx.fillStyle = globeGradient
      ctx.beginPath()
      ctx.arc(centerX, centerY, radius, 0, Math.PI * 2)
      ctx.fill()

      // Inner glow
      const innerGlow = ctx.createRadialGradient(centerX, centerY, radius * 0.8, centerX, centerY, radius)
      innerGlow.addColorStop(0, "transparent")
      innerGlow.addColorStop(1, "rgba(6, 182, 212, 0.1)")
      ctx.fillStyle = innerGlow
      ctx.beginPath()
      ctx.arc(centerX, centerY, radius, 0, Math.PI * 2)
      ctx.fill()

      // Draw grid dots instead of lines for futuristic look
      ctx.fillStyle = "rgba(6, 182, 212, 0.2)"
      for (let lat = -80; lat <= 80; lat += 10) {
        for (let lng = 0; lng < 360; lng += 10) {
          const pos = latLngToXY(lat, lng, currentRotation, size)
          if (pos.isVisible && pos.z > 0) {
            const dotSize = 1 * pos.scale
            ctx.globalAlpha = Math.min(1, (pos.z + 0.3) * 0.8)
            ctx.beginPath()
            ctx.arc(pos.x, pos.y, dotSize, 0, Math.PI * 2)
            ctx.fill()
          }
        }
      }
      ctx.globalAlpha = 1

      // Draw longitude arcs
      ctx.strokeStyle = "rgba(6, 182, 212, 0.1)"
      ctx.lineWidth = 0.5
      for (let lng = 0; lng < 360; lng += 30) {
        ctx.beginPath()
        let started = false
        for (let lat = -90; lat <= 90; lat += 3) {
          const pos = latLngToXY(lat, lng, currentRotation, size)
          if (pos.isVisible && pos.z > 0) {
            if (!started) {
              ctx.moveTo(pos.x, pos.y)
              started = true
            } else {
              ctx.lineTo(pos.x, pos.y)
            }
          } else {
            started = false
          }
        }
        ctx.stroke()
      }

      // Draw latitude arcs
      for (let lat = -60; lat <= 60; lat += 30) {
        ctx.beginPath()
        let started = false
        for (let lng = 0; lng <= 360; lng += 3) {
          const pos = latLngToXY(lat, lng, currentRotation, size)
          if (pos.isVisible && pos.z > 0) {
            if (!started) {
              ctx.moveTo(pos.x, pos.y)
              started = true
            } else {
              ctx.lineTo(pos.x, pos.y)
            }
          } else {
            started = false
          }
        }
        ctx.stroke()
      }

      // Draw connection lines between nearby visible locations
      ctx.strokeStyle = "rgba(6, 182, 212, 0.15)"
      ctx.lineWidth = 0.5
      const visibleLocs = locations
        .map((loc, idx) => ({ ...loc, idx, ...latLngToXY(loc.lat, loc.lng, currentRotation, size) }))
        .filter((loc) => loc.isVisible && loc.z > 0)
        .sort((a, b) => a.z - b.z)

      for (let i = 0; i < visibleLocs.length; i++) {
        for (let j = i + 1; j < visibleLocs.length; j++) {
          const dist = Math.sqrt(
            Math.pow(visibleLocs[i].x - visibleLocs[j].x, 2) + Math.pow(visibleLocs[i].y - visibleLocs[j].y, 2),
          )
          if (dist < 120) {
            ctx.globalAlpha = 0.3 * (1 - dist / 120)
            ctx.beginPath()
            ctx.moveTo(visibleLocs[i].x, visibleLocs[i].y)
            ctx.lineTo(visibleLocs[j].x, visibleLocs[j].y)
            ctx.stroke()
          }
        }
      }
      ctx.globalAlpha = 1

      // Draw location markers
      visibleLocs.forEach((loc) => {
        const isSelected = selectedLocation === loc.idx
        const isHovered = hoveredLocation === loc.idx
        const markerSize = (isSelected || isHovered ? 10 : 7) * loc.scale
        const opacity = Math.min(1, (loc.z + 0.3) * 1.5)

        // Outer pulse for selected
        if (isSelected) {
          const pulse = (Math.sin(Date.now() / 200) + 1) / 2
          ctx.beginPath()
          ctx.arc(loc.x, loc.y, markerSize * 2.5 + pulse * 8, 0, Math.PI * 2)
          ctx.fillStyle = `rgba(16, 185, 129, ${0.2 * opacity})`
          ctx.fill()
        }

        // Glow
        const glowColor = isSelected ? "rgba(16, 185, 129," : isHovered ? "rgba(34, 211, 238," : "rgba(6, 182, 212,"
        const markerGlow = ctx.createRadialGradient(loc.x, loc.y, 0, loc.x, loc.y, markerSize * 3)
        markerGlow.addColorStop(0, `${glowColor} ${opacity * 0.6})`)
        markerGlow.addColorStop(1, `${glowColor} 0)`)
        ctx.fillStyle = markerGlow
        ctx.beginPath()
        ctx.arc(loc.x, loc.y, markerSize * 3, 0, Math.PI * 2)
        ctx.fill()

        // Marker ring
        ctx.strokeStyle = isSelected
          ? `rgba(16, 185, 129, ${opacity})`
          : isHovered
            ? `rgba(34, 211, 238, ${opacity})`
            : `rgba(6, 182, 212, ${opacity})`
        ctx.lineWidth = 2
        ctx.beginPath()
        ctx.arc(loc.x, loc.y, markerSize, 0, Math.PI * 2)
        ctx.stroke()

        // Inner fill
        ctx.fillStyle = isSelected
          ? `rgba(16, 185, 129, ${opacity * 0.3})`
          : isHovered
            ? `rgba(34, 211, 238, ${opacity * 0.3})`
            : `rgba(6, 182, 212, ${opacity * 0.2})`
        ctx.fill()

        // Center dot
        ctx.fillStyle = isSelected
          ? `rgba(52, 211, 153, ${opacity})`
          : isHovered
            ? `rgba(103, 232, 249, ${opacity})`
            : `rgba(103, 232, 249, ${opacity * 0.9})`
        ctx.beginPath()
        ctx.arc(loc.x, loc.y, markerSize * 0.4, 0, Math.PI * 2)
        ctx.fill()

        // Label for selected/hovered
        if ((isSelected || isHovered) && opacity > 0.5) {
          ctx.font = "bold 11px Inter, sans-serif"
          ctx.fillStyle = isSelected ? "rgba(52, 211, 153, 0.95)" : "rgba(103, 232, 249, 0.95)"
          ctx.textAlign = "center"
          ctx.fillText(loc.name, loc.x, loc.y - markerSize - 8)
        }
      })

      // Globe border with glow
      ctx.strokeStyle = "rgba(6, 182, 212, 0.4)"
      ctx.lineWidth = 2
      ctx.beginPath()
      ctx.arc(centerX, centerY, radius, 0, Math.PI * 2)
      ctx.stroke()

      // Highlight arc at edge
      ctx.strokeStyle = "rgba(6, 182, 212, 0.2)"
      ctx.lineWidth = 8
      ctx.beginPath()
      ctx.arc(centerX, centerY, radius - 4, -Math.PI * 0.3, Math.PI * 0.3)
      ctx.stroke()
    }

    draw(rotation)

    if (!isDragging) {
      animationRef.current = requestAnimationFrame(function animate() {
        setRotation((prev) => {
          const newRot = (prev + 0.15) % 360
          rotationRef.current = newRot
          return newRot
        })
        animationRef.current = requestAnimationFrame(animate)
      })
    }

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
      }
    }
  }, [rotation, isDragging, selectedLocation, hoveredLocation, latLngToXY])

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true)
    setLastX(e.clientX)
  }

  const handleMouseMove = (e: React.MouseEvent) => {
    const canvas = canvasRef.current
    if (!canvas) return

    const rect = canvas.getBoundingClientRect()
    const scaleX = canvas.width / rect.width
    const scaleY = canvas.height / rect.height
    const mouseX = (e.clientX - rect.left) * scaleX
    const mouseY = (e.clientY - rect.top) * scaleY

    const locIndex = getLocationAtPoint(mouseX, mouseY, canvas.width, rotationRef.current)
    setHoveredLocation(locIndex)

    if (isDragging) {
      const deltaX = e.clientX - lastX
      setRotation((prev) => (prev + deltaX * 0.5) % 360)
      setLastX(e.clientX)
    }
  }

  const handleMouseUp = () => {
    setIsDragging(false)
  }

  const handleClick = (e: React.MouseEvent) => {
    const canvas = canvasRef.current
    if (!canvas || !onLocationClick) return

    const rect = canvas.getBoundingClientRect()
    const scaleX = canvas.width / rect.width
    const scaleY = canvas.height / rect.height
    const mouseX = (e.clientX - rect.left) * scaleX
    const mouseY = (e.clientY - rect.top) * scaleY

    const locIndex = getLocationAtPoint(mouseX, mouseY, canvas.width, rotationRef.current)
    if (locIndex !== null) {
      onLocationClick(locIndex)
    }
  }

  const handleTouchStart = (e: React.TouchEvent) => {
    setIsDragging(true)
    setLastX(e.touches[0].clientX)
  }

  const handleTouchMove = (e: React.TouchEvent) => {
    if (isDragging) {
      const deltaX = e.touches[0].clientX - lastX
      setRotation((prev) => (prev + deltaX * 0.5) % 360)
      setLastX(e.touches[0].clientX)
    }
  }

  return (
    <div className="w-full flex justify-center items-center relative">
      {/* Background glow */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="w-[350px] h-[350px] rounded-full bg-cyan-500/5 blur-3xl" />
      </div>
      <canvas
        ref={canvasRef}
        width={450}
        height={450}
        className="cursor-grab active:cursor-grabbing relative z-10"
        style={{ cursor: hoveredLocation !== null ? "pointer" : isDragging ? "grabbing" : "grab" }}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={() => {
          handleMouseUp()
          setHoveredLocation(null)
        }}
        onClick={handleClick}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleMouseUp}
      />
    </div>
  )
}
