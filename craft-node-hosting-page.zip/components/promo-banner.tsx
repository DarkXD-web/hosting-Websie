export default function PromoBanner() {
  return (
    <div className="bg-gradient-to-r from-purple-600 via-violet-600 to-purple-600 text-center py-2.5 px-4 text-sm">
      <span className="text-cyan-300 font-semibold">25% off</span> on first order with
      <span className="bg-white/20 px-2 py-0.5 rounded ml-2 font-mono text-xs">CRAFT25</span>
    </div>
  )
}
